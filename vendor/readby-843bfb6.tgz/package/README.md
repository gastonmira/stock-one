# readby

Open-source, self-hosted agent analytics for Next.js: verified AI agents, not user-agent guesses, and the Gaps that make agents misread your site.

> Work in progress. Not published to npm yet.

## Agent Registry

readby recognises Agents through a community-maintained [Agent Registry](./registry/README.md). Adding an Agent takes one JSON file.

The initial entries were seeded from [ai.robots.txt](https://github.com/ai-robots-txt/ai.robots.txt) (MIT); see [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md).

## License

[MIT](./LICENSE)
